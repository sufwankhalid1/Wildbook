To use the Interconnect spot mapper with your instance of Wildbook, you need to configure the .bat file and/or the .sh file to run in your environment. Java 6+ is a prerequisite to run this client.

Example .bat config:

java -cp ./Interconnect.jar org.ecocean.interconnect.Interconnect http://www.whaleshark.org/InterconnectSubmitSpots

Example .sh config (for Linux and Mac):

#! /bin/sh
cd /Users/Jason/Interconnect
java -cp ./Interconnect.jar org.ecocean.interconnect.Interconnect http://www.whaleshark.org/InterconnectSubmitSpots
