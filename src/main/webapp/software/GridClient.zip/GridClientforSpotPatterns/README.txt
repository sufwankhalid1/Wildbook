To use the Grid Client with your instance of Wildbook, you need to configure the .bat file and/or the .sh file to run in your environment. Java 6+ is a prerequisite to run this client.

Example .bat config:

java -classpath .;jdo-api-3.0.jar -Xms256m -Xmx1024m org.ecocean.grid.WorkApplet3 http://www.whaleshark.org

Example .sh config (for Linux and Mac):

#! /bin/sh
cd /Users/Jason/sharkGrid
java -classpath .:jdo-api-3.0.jar -Xms256m -Xmx1024m org.ecocean.grid.WorkApplet3 http://www.whaleshark.org
